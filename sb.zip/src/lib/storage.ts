import Storage from '@itzsunny/storageapi';

export const localStorage = new Storage('LOCAL');
export const sessionStorage = new Storage('SESSION');
